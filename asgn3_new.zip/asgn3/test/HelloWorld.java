public class HelloWorld {

    public static void main(String[] args) {
       // int a,b;
       // for(a=1;a>4; a=a+1){
       // 	 a= 7;
       // }
    	// int a = 5;
    	// do{a = 6;}while(a<5);
    	int a,b;
    	a = 3;
    	b = 4;
    	for(int i=0;i<10;i++){
    		// a = b + 1;
    		// a = a*a;
    	}
    	int c = a;
}
}


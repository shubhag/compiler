public class HelloWorld {

    public static void main(String[] args) {
       // int a;
       // if(a == 1){
       // 		a = 5;
       // }
    	int a;
    a = ( a == 1) ? 2 : 3 ;
    	// int a = 5;
    	// do{a = 6;}while(a<5);
    	// int x = 30;
     //  int y = 10;

     //  if( x > 30 ){
     //     if( y > 10 ){
     //         x = 1;
     //      }
     //   } else{
     //   		y = 1;
     //   }
}
}

// 752
// 629
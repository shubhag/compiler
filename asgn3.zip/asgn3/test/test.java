public class testing{
    public static void main(String args[]) {
        int x = 10;

        while( x < 13 ) {
            System.out.print("x : " + x );
            x++;
            System.out.print(".................\n");
        }
        int y = 10;

        if( y == 10 ){
            System.out.print("This is if\" statement");
        }else{
            System.out.print("This is else statement");
        }


        for(int z = 10; z < 120; z = z+1) {
            System.out.print("value of z : " + z );
            System.out.print("\n");
        }

        double[] list = {1.91, 2.19, 3.14, 3.15};

        // Print all the array elements
        for (int i = 0; i < myList.length; i++) {
            System.out.println(myList[i] + "........ ");
        }


        int i =0;  
   
        do
        {
          System.out.println("i is : " + i);
          i++;
         
        }while(i < 5);


        
        char grade = 'C';

        switch(grade)
        {
         case 'A' :
            System.out.println("Excellent!"); 
            break;
         case 'B' :
         case 'C' :
            System.out.println("Well done");
            break;
         case 'D' :
            System.out.println("You passed");
         case 'F' :
            System.out.println("Better try again");
            break;
         default :
            System.out.println("Invalid grade");
        }
        System.out.println("Your grade is " + grade);


        int a , b;
        a = 10;
        b = (a == 1) ? 20: 30;
        System.out.println( "Value of b is : " +  b );
        a = 7 + 3 * 2 - 12;
        b = (a == 1) ? 20: 30;
        System.out.println( "New value of b is : " +  b );

        a=45;
        b=24;
        int c = a^b;
        System.out.println( "Value of c is : " +  c );
        c = ~c;
        System.out.println( "New value of c is : " +  c );

        boolean m = 0;
        m = ~m;
        System.out.println( "New value of m is : " +  m );

        int c = minFunction(a, b);
        System.out.println("Minimum Value = " + c);
        
   }
         /** returns the minimum of two numbers */
       public static int minFunction(int n1, int n2) {
          int min;
          if (n1 > n2)
             min = n2;
          else
             min = n1;

          return min; 
       }
}